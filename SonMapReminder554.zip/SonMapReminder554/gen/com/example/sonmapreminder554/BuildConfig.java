/** Automatically generated file. DO NOT MODIFY */
package com.example.sonmapreminder554;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}