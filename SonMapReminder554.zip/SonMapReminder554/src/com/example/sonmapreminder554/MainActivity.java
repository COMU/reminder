package com.example.sonmapreminder554;

import com.google.android.gms.maps.MapFragment;

import android.os.Bundle;

public class MainActivity extends MapFragment {

    @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

	private void setContentView(int activityMain) {
		// TODO Auto-generated method stub
		
	}
}